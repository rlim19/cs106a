import stanford.karel.*;

public class BlankKarel {
	public void run() {
		// your code here
	}
}
